@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.input.keys;

import javax.annotation.ParametersAreNonnullByDefault;
