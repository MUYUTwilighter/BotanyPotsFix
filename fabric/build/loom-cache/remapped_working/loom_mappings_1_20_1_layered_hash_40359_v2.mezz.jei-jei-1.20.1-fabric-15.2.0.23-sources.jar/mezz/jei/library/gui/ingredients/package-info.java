@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.gui.ingredients;

import javax.annotation.ParametersAreNonnullByDefault;
