@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.gui.overlay.bookmarks;

import javax.annotation.ParametersAreNonnullByDefault;
