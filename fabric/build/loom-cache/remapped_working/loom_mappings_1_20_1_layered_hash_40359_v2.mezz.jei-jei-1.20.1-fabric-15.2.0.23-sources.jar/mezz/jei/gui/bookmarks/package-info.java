@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.gui.bookmarks;

import javax.annotation.ParametersAreNonnullByDefault;
