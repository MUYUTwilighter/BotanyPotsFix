@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.fabric;

import javax.annotation.ParametersAreNonnullByDefault;
