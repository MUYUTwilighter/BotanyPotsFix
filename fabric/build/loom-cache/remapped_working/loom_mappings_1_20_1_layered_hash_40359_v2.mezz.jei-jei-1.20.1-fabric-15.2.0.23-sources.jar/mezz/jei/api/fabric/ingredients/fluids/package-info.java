@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.fabric.ingredients.fluids;

import javax.annotation.ParametersAreNonnullByDefault;
