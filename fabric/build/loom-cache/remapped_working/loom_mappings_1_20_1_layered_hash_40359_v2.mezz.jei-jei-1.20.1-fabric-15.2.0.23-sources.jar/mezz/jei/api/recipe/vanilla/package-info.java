@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.vanilla;

import javax.annotation.ParametersAreNonnullByDefault;
