@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.category.extensions.vanilla.crafting;

import javax.annotation.ParametersAreNonnullByDefault;
