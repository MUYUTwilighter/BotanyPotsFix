package net.darkhax.bookshelf.api.event.entity;

import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

@FunctionalInterface
public interface IItemUseTickEvent {

    void onUseTick(LivingEntity user, ItemStack stack, AtomicInteger duration);
}