package net.darkhax.bookshelf.api.registry;

import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;

public interface IRegistryObject<T> extends Supplier<T> {

    ResourceLocation getRegistryName();
}
